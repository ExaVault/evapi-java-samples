import java.util.Random;

import io.swagger.client.*;
import io.swagger.client.auth.*;
import io.swagger.client.model.*;
import io.swagger.client.api.UsersApi;


public class CreateUser extends JavaExamples {
	
	/**
	 * CreateUser - Use the UsersApi to create a new user with a home directory
	 * 
	 */

	/**
	 * To use this example, add your credentials to main JavaExamples class in this project
	 * 
	 * 
	 * To obtain your API Key and Token, you'll need to use the Developer page within the web file manager
	 * See https://www.exavault.com/developer/api-docs/#section/Obtaining-Your-API-Key-and-Access-Token
	 * 
	 * Access tokens do not expire, so you should only need to obtain the key and token once.
	 * 
	 */
	
	 /**
	  *  We are demonstrating the use of the UsersApi, which is used to create, update and remove users in your account.
	  * 
	  */
	
	public static void main(String[] args) {
		
		 // Construct main class to set evAccessToken, evApiKey and apiUrl
		 JavaExamples ob1 = new JavaExamples();
		 	
		 // random value will allow to create unique user in the account
		 Random rand = new Random();
		 
		 UsersApi usersApiInstance = new UsersApi(apiInstance);
		 
		 // See https://www.exavault.com/developer/api-docs/#operation/addUser for the request body schema
		 Body5 body = new Body5();
	     
	     body.setEmail("testuser@example.com");
	     body.setPassword("testpaSsword8");
	     body.setHomeResource("/");
	     body.setPermissions("upload,download,modify,delete");
	     body.setRole(Body5.RoleEnum.USER);
	     body.setTimeZone("America/Los_Angeles");
	     body.setUsername("javatestuser"+rand.nextInt());
	     body.setWelcomeEmail(true);

	     try {
	    	 // See https://www.exavault.com/developer/api-docs/#operation/addUser for the response body schema
	         UserResponse result = usersApiInstance.addUser(evApiKey, evAccessToken, body);
	         
	         //print out the response
	         System.out.println(result);
	     } catch (ApiException e) {
	         System.err.println("Exception when calling UsersApi#addUser");
	         e.printStackTrace();
	     }
	     
	}

}

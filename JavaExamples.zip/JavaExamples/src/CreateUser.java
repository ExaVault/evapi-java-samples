import java.util.Random;

import io.swagger.client.*;
import io.swagger.client.auth.*;
import io.swagger.client.model.*;
import io.swagger.client.api.UsersApi;


public class CreateUser extends JavaExamples {
	
	public static void main(String[] args) {
		
		 JavaExamples ob1 = new JavaExamples();
		 
		 Random rand = new Random();
		 UsersApi usersApiInstance = new UsersApi(apiInstance);
		 
		 Body5 body = new Body5(); // Body5 | 
	     
	     body.setEmail("testuser@example.com");
	     body.setPassword("testpaSsword8");
	     body.setHomeResource("/");
	     body.setPermissions("upload,download,modify,delete");
	     body.setRole(Body5.RoleEnum.USER);
	     body.setTimeZone("America/Los_Angeles");
	     body.setUsername("javatestuser"+rand.nextInt());
	     body.setWelcomeEmail(true);

	     try {
	         UserResponse result = usersApiInstance.addUser(evApiKey, evAccessToken, body);
	         System.out.println(result);
	     } catch (ApiException e) {
	         System.err.println("Exception when calling UsersApi#addUser");
	         e.printStackTrace();
	     }
	     
	}

}

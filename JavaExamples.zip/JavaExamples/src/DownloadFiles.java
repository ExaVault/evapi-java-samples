import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;

import io.swagger.client.*;
import io.swagger.client.auth.*;
import io.swagger.client.model.*;
import io.swagger.client.api.ResourcesApi;

public class DownloadFiles extends JavaExamples {
	
	public static void main(String[] args) {
		
		 JavaExamples ob1 = new JavaExamples();
		
		 //Upload more files into folder
		 ResourcesApi resourcesApiInstance = new ResourcesApi(apiInstance);
		 
		 File folder = new File("files");
		 File[] listOfFiles = folder.listFiles();


		 for (int x = 1; x <= 4; x++) {
		    for (File file : listOfFiles) {
		        if (file.isFile()) {
		          String path = "/java-upload/" + file.getName(); // String | Destination path for the file being uploaded, including the file name.
		            
		          Integer fileSize = new Long (file.length()).intValue(); // Integer | File size, in bits, of the file being uploaded.
		          Integer offsetBytes = 0; // Integer | Allows a file upload to resume at a certain number of bytes.
		          Boolean resume = false; // Boolean | True if upload resume is supported, false if it isn't. 
		          Boolean allowOverwrite = false; // Boolean | True if a file with the same name is found in the designated path, should be overwritten. False if different file names should be generated. 
		          try {
		              ResourceResponse result = resourcesApiInstance.uploadFile(evApiKey, evAccessToken, path, fileSize, file, offsetBytes, resume, allowOverwrite);
		          } catch (ApiException e) {
		              System.err.println("Exception when calling ResourcesApi#uploadFile");
		              e.printStackTrace();
		          }
		          
		        }
		    }
		 }
		    
		 //now download only .csv files   
		 String resource = "/java-upload"; // String | Resource identifier to get resources for. Can be path/id/name. Required if hash and path are null
	     String sort = "name"; // String | Endpoint support multiple sort fields by allowing array of sort params. Sort fields should be applied in the order specified. The sort order for each sort field is ascending unless it is prefixed with a minus (“-“), in which case it will be descending.
	     Integer offset = 0; // Integer | Determines which item to start on for pagination. Use zero (0) to start at the beginning of the list.
	     Integer limit = 50; // Integer | The number of files to limit the result. Cannot be set higher than 100. If you have more than one hundred files in your directory, make multiple calls to **getResourceList**, incrementing the **offset** parameter, above.
	     String type = null; // String | Optional param to get only folder resources.
	     String include = null; // String | Comma separated list of relationships to include in response. Possible values are `share`, `notification`, `directFile`, `parentNode`.
	     String name = "*.csv"; // String | Text to match resource names
	     
	     
	     try {
	    	 
	    	 ResourceCollectionResponse result = resourcesApiInstance.listResources(evApiKey, evAccessToken, resource, sort, offset, limit, type, name, include);
	    	 
	    	 List<Resource> data = result.getData();
	    	 List<String> resources = new ArrayList<>();
	    	 
	    	 for (Resource item : data) {  
	    		    resources.add("id:"+item.getId());
	    	 }

	    	 System.out.println(data);
	    	
	 	     String downloadName = "csv-files.zip"; // String | If zipping multiple files, the name of the zip file to create and download.
	 	     Boolean polling = false; // Boolean | Used when downloading multiple files so url will be pulled till zip file is created.
	 	     String pollingZipName = null; // String | Reference to the previously created zip for polling operation.
	 	     
	 	     
	 	    File fileContent = resourcesApiInstance.download(evApiKey, evAccessToken, resources, downloadName, polling, pollingZipName);
		 	String saveFilePath = "downloads" + File.separator + downloadName;
		
		 	readwrite(fileContent, saveFilePath);
	     
	     } catch (ApiException | IOException e) {
	         System.err.println("Exception when calling ResourcesApi#listResources");
	         e.printStackTrace();
	     }  

	
	}
	
	public static void readwrite(File infile,String destination) throws IOException 
	{
		

    	FileInputStream instream = null;
    	FileOutputStream outstream = null;
 

    	    File outfile = new File(destination);
    	    outfile.createNewFile();
 
    	    instream = new FileInputStream(infile);
    	    outstream = new FileOutputStream(outfile);
 
    	    byte[] buffer = new byte[1024];
 
    	    int length;
    	    /*copying the contents from input stream to
    	     * output stream using read and write methods
    	     */
    	    while ((length = instream.read(buffer)) > 0){
    	    	outstream.write(buffer, 0, length);
    	    }

    	    //Closing the input/output file streams
    	    instream.close();
    	    outstream.close();

    	    System.out.println("File copied successfully!!");

	    

	}
	
	
}

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;

import io.swagger.client.*;
import io.swagger.client.auth.*;
import io.swagger.client.model.*;
import io.swagger.client.api.ResourcesApi;

public class DownloadFiles extends JavaExamples {
	
	/**
	 * DonloadFiles - Use the ResourcesApi to download all of the CSV files found within a folder tree
	 * 
	 */

	/**
	 * To use this example, add your credentials to main JavaExamples class in this project
	 * 
	 * 
	 * To obtain your API Key and Token, you'll need to use the Developer page within the web file manager
	 * See https://www.exavault.com/developer/api-docs/#section/Obtaining-Your-API-Key-and-Access-Token
	 * 
	 * Access tokens do not expire, so you should only need to obtain the key and token once.
	 * 
	 */
	
	 /**
	  * 
	  *  We are demonstrating the use of the ResourcesApi, which can be used to manage files and folders in your account
	  * 
	  */
	
	public static void main(String[] args) {
			
		 // Construct main class to set evAccessToken, evApiKey and apiUrl
		 JavaExamples ob1 = new JavaExamples();
		
		 // Make more files in the folder as we are going to download some of them
		 ResourcesApi resourcesApiInstance = new ResourcesApi(apiInstance);
		 
		 File folder = new File("files");
		 File[] listOfFiles = folder.listFiles();

		 // make couple copies of the same file in the account
		 // fals allowOverwrite flag allows us to make copies of the file
		 for (int x = 1; x <= 4; x++) {
		    for (File file : listOfFiles) {
		        if (file.isFile()) {
		          String path = "/java-upload/" + file.getName(); // String | Destination path for the file being uploaded, including the file name.
		            
		          Integer fileSize = new Long (file.length()).intValue(); // Integer | File size, in bits, of the file being uploaded.
		          Integer offsetBytes = 0; // Integer | Allows a file upload to resume at a certain number of bytes.
		          Boolean resume = false; // Boolean | True if upload resume is supported, false if it isn't. 
		          Boolean allowOverwrite = false; // Boolean | True if a file with the same name is found in the designated path, should be overwritten. False if different file names should be generated. 
		          try {
		        	  // The uploadFile method of the ResourcesApi class will let us upload a file to our account
		    	      // See https://www.exavault.com/developer/api-docs/#operation/uploadFile for the details of this method
		              ResourceResponse result = resourcesApiInstance.uploadFile(evApiKey, evAccessToken, path, fileSize, file, offsetBytes, resume, allowOverwrite);
		          } catch (ApiException e) {
		              System.err.println("Exception when calling ResourcesApi#uploadFile");
		              e.printStackTrace();
		          }
		          
		        }
		    }
		 }
		    
		 // now  we can download only .csv files   
		 // we are using name param for searching only .csv files.
		 String resource = "/java-upload"; // String | Resource identifier to get resources for. Can be path/id/name. Required if hash and path are null
	     String sort = "name"; // String | Endpoint support multiple sort fields by allowing array of sort params. Sort fields should be applied in the order specified. The sort order for each sort field is ascending unless it is prefixed with a minus (“-“), in which case it will be descending.
	     Integer offset = 0; // Integer | Determines which item to start on for pagination. Use zero (0) to start at the beginning of the list.
	     Integer limit = 50; // Integer | The number of files to limit the result. Cannot be set higher than 100. If you have more than one hundred files in your directory, make multiple calls to **getResourceList**, incrementing the **offset** parameter, above.
	     String type = null; // String | Optional param to get only folder resources.
	     String include = null; // String | Comma separated list of relationships to include in response. Possible values are `share`, `notification`, `directFile`, `parentNode`.
	     String name = "*.csv"; // String | Text to match resource names
	     
	     
	     try {
	    	 
	    	 // See https://www.exavault.com/developer/api-docs/#operation/listResources for the response schema
	    	 ResourceCollectionResponse result = resourcesApiInstance.listResources(evApiKey, evAccessToken, resource, sort, offset, limit, type, name, include);
	    	 
	    	 //get the data variable of the ResourceCollectionResponse response object
	    	 List<Resource> data = result.getData();
	    	
	    	 List<String> resources = new ArrayList<>();
	    	 
	    	 // iterate through all resources we got back and make a list of id identifiers
	    	 // it will be used to download only these files
	    	 for (Resource item : data) {  
	    		    resources.add("id:"+item.getId());
	    	 }

	    	
	 	     String downloadName = "csv-files.zip"; // String | If zipping multiple files, the name of the zip file to create and download.
	 	     Boolean polling = false; // Boolean | Used when downloading multiple files so url will be pulled till zip file is created.
	 	     String pollingZipName = null; // String | Reference to the previously created zip for polling operation.
	 	     
	 	     // The body of the result is the binary content of our file(s), 
	 	     // We write that content into a single file, named with .zip if there were multiple files 
	 	     // downloaded or just named .csv if not (since we were storing csvs)
	 	     File fileContent = resourcesApiInstance.download(evApiKey, evAccessToken, resources, downloadName, polling, pollingZipName);
		 	
	 	     String saveFilePath = "downloads" + File.separator + downloadName;
	 	     
	 	     // save the file to the downloads folder inside this project
		 	 readwrite(fileContent, saveFilePath);
	     
	     } catch (ApiException | IOException e) {
	         System.err.println("Exception when calling ResourcesApi#listResources");
	         e.printStackTrace();
	     }  

	
	}
	
	// helper function for file writing
	public static void readwrite(File infile,String destination) throws IOException 
	{
		

    	FileInputStream instream = null;
    	FileOutputStream outstream = null;
 

    	    File outfile = new File(destination);
    	    outfile.createNewFile();
 
    	    instream = new FileInputStream(infile);
    	    outstream = new FileOutputStream(outfile);
 
    	    byte[] buffer = new byte[1024];
 
    	    int length;
    	    /*copying the contents from input stream to
    	     * output stream using read and write methods
    	     */
    	    while ((length = instream.read(buffer)) > 0){
    	    	outstream.write(buffer, 0, length);
    	    }

    	    //Closing the input/output file streams
    	    instream.close();
    	    outstream.close();

    	    System.out.println("File copied successfully!!");

	    

	}
	
	
}

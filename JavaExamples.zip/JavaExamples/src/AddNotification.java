import io.swagger.client.*;
import io.swagger.client.auth.*;
import io.swagger.client.model.*;
import io.swagger.client.api.ResourcesApi;
import io.swagger.client.api.NotificationsApi;
import java.util.*;

public class AddNotification extends JavaExamples {
	
	/**
	 * AddNotification - Use the NotificationsApi to create a Notification on a folder
	 */

	/**
	 * To use this example, add your credentials to main JavaExamples class in this project
	 * 
	 * 
	 * To obtain your API Key and Token, you'll need to use the Developer page within the web file manager
	 * See https://www.exavault.com/developer/api-docs/#section/Obtaining-Your-API-Key-and-Access-Token
	 * 
	 * Access tokens do not expire, so you should only need to obtain the key and token once.
	 * 
	 */
	
	/**
	 * 
	 *  We are demonstrating the use of the NotificationsApi, which can be used to manage notification settings 
	 *	for files and folders
	 *
	 *	 For this demo, we'll create a new folder and add notification on it. If you have 
	 *	 an existing file or folder that you want to create a notification for, you won't need the step where
	 *	 we use the ResourcesApi to create the folders first.
	 */
	
	public static void main(String[] args) {
		
		// Construct main class to set evAccessToken, evApiKey and apiUrl
		JavaExamples ob1 = new JavaExamples();
		
		
		
		ResourcesApi resourcesApiInstance = new ResourcesApi(apiInstance);
		NotificationsApi notificationsApiInstance = new NotificationsApi(apiInstance);
		
		Random rand = new Random();
		
		// create folder to set notification on it it will have random name each time
		// See https://www.exavault.com/developer/api-docs/#operation/addFolder for the request body schema
		Body8 body = new Body8();
	    body.setPath("/java-upload/notification-sample"+rand.nextInt());
	    Integer folderId = null;
	    
	    try {
	    	// The addFolder method of the ResourcesApi returns a ResourceResponse object
	        // See https://www.exavault.com/developer/api-docs/#operation/addFolder for the details of the response object
	        ResourceResponse result = resourcesApiInstance.addFolder(evApiKey, evAccessToken, body);
	        
	        // Get new folder id so we can than set notification on it
	        folderId = result.getData().getId();
	    } catch (ApiException e) {
	        System.err.println("Exception when calling ResourcesApi#addFolder");
	        e.printStackTrace();
	    }
	    
	    
	   
	    //   - We will pass in the id identifier of the folder in the resource parameter
	    //   - We want to be notified by email whenever anyone uploads to our folder, so we are using
	    //   the constant "notice_user_all", which means anyone, including users and share recipients.
	    //   See  https://www.exavault.com/developer/api-docs/#operation/addNotification  for a list of other 
	    //   constants that can be used in the usernames array
	    //   - We are sending the notification to a bunch of email addresses
	    //   - We have added an optional custom message to be included in each notification email
	    
	    // No we will create notification
		// See https://www.exavault.com/developer/api-docs/#operation/addNotification for the request body schema
	    Body4 body4 = new Body4();
	    
	    List<String> usernames =  Arrays.asList("notice_user_all");
	    List<String> recipients = Arrays.asList("testnotifications@example.com", "testnotifications1@example.com", "testnotifications2@example.com");
	    
	    body4.setResource("id:"+folderId);
	    body4.setUsernames(usernames);
	    body4.setRecipients(recipients);
	    body4.setAction(Body4.ActionEnum.UPLOAD);
	    body4.setType(Body4.TypeEnum.FOLDER);
	    body4.setMessage("New files have been uploaded");
	    body4.setSendEmail(true);
	    		 
	    
	    try {
	    	// The addNotification method of the NotificationsApi returns a NotificationResponse object
	        // See https://www.exavault.com/developer/api-docs/v2#operation/addNotification for the details of the response object
	        NotificationResponse result = notificationsApiInstance.addNotification(evApiKey, evAccessToken, body4);
	        
	        // print out response
	        System.out.println(result);
	    } catch (ApiException e) {
	        System.err.println("Exception when calling NotificationsApi#addNotification");
	        e.printStackTrace();
	    }
	    
	}

}

import io.swagger.client.*;
import io.swagger.client.auth.*;
import io.swagger.client.model.*;
import io.swagger.client.api.ResourcesApi;
import io.swagger.client.api.NotificationsApi;
import java.util.*;

public class AddNotification extends JavaExamples {
	
	public static void main(String[] args) {
		
		JavaExamples ob1 = new JavaExamples();
		
		ResourcesApi resourcesApiInstance = new ResourcesApi(apiInstance);
		NotificationsApi notificationsApiInstance = new NotificationsApi(apiInstance);
		
		Random rand = new Random();
		
		// create folder to set notification on it
		Body8 body = new Body8(); // Body8 | 
	    body.setPath("/java-upload/notification-sample"+rand.nextInt());
	    Integer folderId = null;
	    
	    try {
	        ResourceResponse result = resourcesApiInstance.addFolder(evApiKey, evAccessToken, body);
	        
	        folderId = result.getData().getId();
	    } catch (ApiException e) {
	        System.err.println("Exception when calling ResourcesApi#addFolder");
	        e.printStackTrace();
	    }
	    
	
	    Body4 body4 = new Body4(); // Body4 | 
	    
	    List<String> usernames =  Arrays.asList("notice_user_all");
	    List<String> recipients = Arrays.asList("testnotifications@example.com", "testnotifications1@example.com", "testnotifications2@example.com");
	    
	    body4.setResource("id:"+folderId);
	    body4.setUsernames(usernames);
	    body4.setRecipients(recipients);
	    body4.setAction(Body4.ActionEnum.UPLOAD);
	    body4.setType(Body4.TypeEnum.FOLDER);
	    body4.setMessage("New files have been uploaded");
	    body4.setSendEmail(true);
	    		 
	    
	    try {
	        NotificationResponse result = notificationsApiInstance.addNotification(evApiKey, evAccessToken, body4);
	        System.out.println(result);
	    } catch (ApiException e) {
	        System.err.println("Exception when calling NotificationsApi#addNotification");
	        e.printStackTrace();
	    }
	    
	}

}

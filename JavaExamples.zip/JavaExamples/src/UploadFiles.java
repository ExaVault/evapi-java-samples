import java.io.File;
import io.swagger.client.*;
import io.swagger.client.auth.*;
import io.swagger.client.model.*;
import io.swagger.client.api.ResourcesApi;

public class UploadFiles extends JavaExamples {
	
	/**
	 * UploadFiles - Use the ResourcesApi to upload a file to your account
	 * 
	 */

	/**
	 * To use this example, add your credentials to main JavaExamples class in this project
	 * 
	 * 
	 * To obtain your API Key and Token, you'll need to use the Developer page within the web file manager
	 * See https://www.exavault.com/developer/api-docs/#section/Obtaining-Your-API-Key-and-Access-Token
	 * 
	 * Access tokens do not expire, so you should only need to obtain the key and token once.
	 * 
	 */
	
	 /**
	  *  We are demonstrating the use of the ResourcesApi, which can be used to manage files and folders in your account
 	  *  For this demo, we'll upload a file found in /files folder inside this project.
 	  *  There are parameters to control whether files can be overwritten by repeated uploads
	  * 
	  */
	
  public static void main(String[] args) {
		
	    // Construct main class to set evAccessToken, evApiKey and apiUrl
		JavaExamples ob1 = new JavaExamples();
		
		ResourcesApi resourcesApiInstance = new ResourcesApi(apiInstance);
	    
	    File folder = new File("files");
	    File[] listOfFiles = folder.listFiles();
	   
	    for (File file : listOfFiles) {
	    	  if (file.isFile()) {
	    	    String path = "/java-upload/" + file.getName(); // String | Destination path for the file being uploaded, including the file name.
	    	     
	    	    Integer fileSize = new Long (file.length()).intValue(); // Integer | File size, in bits, of the file being uploaded.
	    	    Integer offsetBytes = 0; // Integer | Allows a file upload to resume at a certain number of bytes.
	    	    Boolean resume = false; // Boolean | True if upload resume is supported, false if it isn't. 
	    	    Boolean allowOverwrite = false; // Boolean | True if a file with the same name is found in the designated path, should be overwritten. False if different file names should be generated. 
	    	    try {
	    	       // The uploadFile method of the ResourcesApi class will let us upload a file to our account
	    	       // See https://www.exavault.com/developer/api-docs/#operation/uploadFile for the details of this method
	    	       ResourceResponse result = resourcesApiInstance.uploadFile(evApiKey, evAccessToken, path, fileSize, file, offsetBytes, resume, allowOverwrite);
	    	       
	    	       // print out the response
	    	       System.out.println(result);
	    	    } catch (ApiException e) {
	    	       System.err.println("Exception when calling ResourcesApi#uploadFile");
	    	       e.printStackTrace();
	    	    }
	    	   
	    	  }
	    }
	    

	    
	}

}

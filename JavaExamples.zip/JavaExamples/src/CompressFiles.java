import java.io.File;
import java.util.*;

import io.swagger.client.*;
import io.swagger.client.model.*;
import io.swagger.client.auth.*;
import io.swagger.client.api.ResourcesApi;

public class CompressFiles extends JavaExamples {
	
	/**
	 * CompressFiles - Use the Resources API to compress files 
	 * 
	 */

	/**
	 * To use this example, add your credentials to main JavaExamples class in this project
	 * 
	 * 
	 * To obtain your API Key and Token, you'll need to use the Developer page within the web file manager
	 * See https://www.exavault.com/developer/api-docs/#section/Obtaining-Your-API-Key-and-Access-Token
	 * 
	 * Access tokens do not expire, so you should only need to obtain the key and token once.
	 * 
	 */
	
	/** 
	 * We are demonstrating the use of the ResourcesApi, which is used for file operations (upload, download, delete, etc)
	 *
	 * For this demo, we'll create a new folder(if not exist) and upload some files into it. Then we'll compress all files into
	 * a new zip file in the folder
	 */
	
	public static void main(String[] args) {
			
		 // Construct main class to set evAccessToken, evApiKey and apiUrl
		 JavaExamples ob1 = new JavaExamples();
		
		 // Upload more files into folder
		 ResourcesApi resourcesApiInstance = new ResourcesApi(apiInstance);
		 
		 File folder = new File("files");
		 File[] listOfFiles = folder.listFiles();


		 for (int x = 1; x <= 4; x++) {
		    for (File file : listOfFiles) {
		        if (file.isFile()) {
		        	
		          // Specifying a full upload path also allows auto folder creation of it not exist
		          // In this examples if java-upload not exist in your account it will be auto created
		          String path = "/java-upload/" + file.getName(); // String | Destination path for the file being uploaded, including the file name.
		            
		          Integer fileSize = new Long (file.length()).intValue(); // Integer | File size, in bits, of the file being uploaded.
		          Integer offsetBytes = 0; // Integer | Allows a file upload to resume at a certain number of bytes.
		          Boolean resume = true; // Boolean | True if upload resume is supported, false if it isn't. 
		          Boolean allowOverwrite = true; // Boolean | True if a file with the same name is found in the designated path, should be overwritten. False if different file names should be generated. 
		          try {
		              ResourceResponse result = resourcesApiInstance.uploadFile(evApiKey, evAccessToken, path, fileSize, file, offsetBytes, resume, allowOverwrite);
		          } catch (ApiException e) {
		              System.err.println("Exception when calling ResourcesApi#uploadFile");
		              e.printStackTrace();
		          }
		          
		        }
		    }
		 }
		 
		 // No we will select all files in the folder
		 // See https://www.exavault.com/developer/api-docs/#operation/compressFiles for the request body schema
		 Body10 body = new Body10();
		 List<String> resources = Arrays.asList("all:/java-upload");
		 
		 body.setResources(resources);
		 
		 try {
			 // The compressFiles method of the ResourcesApi returns a ResourceResponse object
		     // See https://www.exavault.com/developer/api-docs/#operation/compressFiles for the details of the response object
		     ResourceResponse result = resourcesApiInstance.compressFiles(evApiKey, evAccessToken, body);
		     
		     //print out response object
		     System.out.println(result);
		 } catch (ApiException e) {
		     System.err.println("Exception when calling ResourcesApi#compressFiles");
		     e.printStackTrace();
		 }
		 
		 
		 
	}

}

import java.io.File;
import java.util.*;

import io.swagger.client.*;
import io.swagger.client.model.*;
import io.swagger.client.auth.*;
import io.swagger.client.api.ResourcesApi;

public class CompressFiles extends JavaExamples {
	
	public static void main(String[] args) {
		
		 JavaExamples ob1 = new JavaExamples();
		
		 //Upload more files into folder
		 ResourcesApi resourcesApiInstance = new ResourcesApi(apiInstance);
		 
		 File folder = new File("files");
		 File[] listOfFiles = folder.listFiles();


		 for (int x = 1; x <= 4; x++) {
		    for (File file : listOfFiles) {
		        if (file.isFile()) {
		          String path = "/java-upload/" + file.getName(); // String | Destination path for the file being uploaded, including the file name.
		            
		          Integer fileSize = new Long (file.length()).intValue(); // Integer | File size, in bits, of the file being uploaded.
		          Integer offsetBytes = 0; // Integer | Allows a file upload to resume at a certain number of bytes.
		          Boolean resume = true; // Boolean | True if upload resume is supported, false if it isn't. 
		          Boolean allowOverwrite = true; // Boolean | True if a file with the same name is found in the designated path, should be overwritten. False if different file names should be generated. 
		          try {
		              ResourceResponse result = resourcesApiInstance.uploadFile(evApiKey, evAccessToken, path, fileSize, file, offsetBytes, resume, allowOverwrite);
		          } catch (ApiException e) {
		              System.err.println("Exception when calling ResourcesApi#uploadFile");
		              e.printStackTrace();
		          }
		          
		        }
		    }
		 }
		 
		 
		 Body10 body = new Body10(); // Body10 | 
		 List<String> resources = Arrays.asList("all:/java-upload");
		 
		 body.setResources(resources);
		 
		 try {
		     ResourceResponse result = resourcesApiInstance.compressFiles(evApiKey, evAccessToken, body);
		     System.out.println(result);
		 } catch (ApiException e) {
		     System.err.println("Exception when calling ResourcesApi#compressFiles");
		     e.printStackTrace();
		 }
		 
		 
		 
	}

}

import io.swagger.client.*;
import io.swagger.client.auth.*;
import io.swagger.client.model.*;
import io.swagger.client.api.UsersApi;

import java.util.*;

public class GetUsers extends JavaExamples {
	
	public static void main(String[] args) {
		
		 JavaExamples ob1 = new JavaExamples();
		
		 UsersApi usersApiInstance = new UsersApi(apiInstance);
		 
		 String username = null; // String | The username of the user you are looking for. Only entries with the same username as this will be in the list of results. Does not support wildcard searches.
	     String nickname = null; // String | Nickname to search for. Ignored if `username` is provided. Supports wildcard searches.
	     String email = null; // String | Email to search for. Ignored if `username` is provided. Supports wildcard searches
	     String role = null; // String | Types of users to include the list. Ignored if `username` is provided. Valid options are **admin**, **master** and **user**
	     Integer status = null; // Integer | Whether a user is locked. Ignored if `username` is provided. **0** means user is locked, **1** means user is not locked. 
	     String homeDir = null; // String | Path for user's home directory. Ignored if `username` is provided. Supports wildcard searches.
	     String search = null; // String | Searches the nickname, email, role and homeDir fields for the provided value. Ignored if `username` is provided. Supports wildcard searches.
	     Integer offset = 0; // Integer | Starting user record in the result set. Can be used for pagination.
	     String sort = null; // String | Sort order or matching users. You can sort by multiple columns by separating sort options with a comma; the sort will be applied in the order specified. The sort order for each sort field is ascending unless it is prefixed with a minus (“-“), in which case it will be descending.  Valid sort fields are: **nickname**, **username**, **email**, **homeDir** and **modified**
	     Integer limit = null; // Integer | Number of users to return. Can be used for pagination.
	     String include = "ownerAccount"; // String | Comma separated list of relationships to include in response. Valid options are **homeResource** and **ownerAccount**.
	   

	     List<User> users = new ArrayList<User>();
	     try {
	         UserCollectionResponse response = usersApiInstance.listUsers(evApiKey, evAccessToken, username, nickname, email, role, status, homeDir, search, offset, sort, limit, include);
	         
	         System.out.println(response);
	         
	         for(User item: response.getData()) {
	        	 users.add(item);
	         }
	         
	         if ( response.getTotalResults()  > response.getTotalResults() + offset) {
	        	 offset = offset+response.getTotalResults();
	        	 response = usersApiInstance.listUsers(evApiKey, evAccessToken, username, nickname, email, role, status, homeDir, search, offset, sort, limit, include);
	        	 
	        	 for(User item: response.getData()) {
		        	 users.add(item);
		         }
	         }

	         
	       //  System.out.println(users);
	     } catch (ApiException e) {
	    	 System.err.println(e.getResponseBody());
	         System.err.println("Exception when calling UsersApi#listUsers");
	         e.printStackTrace();
	     }
	     
	}
}

import io.swagger.client.*;
import io.swagger.client.model.*;
import io.swagger.client.auth.*;
import io.swagger.client.api.AccountApi;

import com.google.gson.internal.LinkedTreeMap;

import java.text.CharacterIterator;
import java.text.StringCharacterIterator;

import java.util.*;


public class GetAccount extends JavaExamples {
	

	public static void main(String[] args) {
		
		JavaExamples ob1 = new JavaExamples();
		
	    AccountApi accountApiInstance = new AccountApi(apiInstance);
	    
	    // Include masterUser to the response
	    String include = "masterUser";
	    

	     try {
	    	 AccountResponse result = accountApiInstance.getAccount(evApiKey, evAccessToken, include);
	    	 
	         long percentUsed = Math.round((double)result.getData().getAttributes().getQuota().getDiskUsed() / (double)result.getData().getAttributes().getQuota().getDiskLimit() * 100);
	         
	         System.out.println("Used: " + humanReadableByteCountBin(result.getData().getAttributes().getQuota().getDiskUsed()) + " (" + percentUsed + "%)"  );
	         System.out.println("Total size: " + humanReadableByteCountBin(result.getData().getAttributes().getQuota().getDiskLimit()));
	         
	         List<Object> included = result.getIncluded();
	         LinkedTreeMap user = (LinkedTreeMap) included.get(0);
	         
	         // get master user id
	         System.out.println("Master user id: " + ((Double) user.get("id")).intValue());
	     } catch (ApiException e) {
	         System.err.println("Exception when calling AccountApi#getAccount");
	         e.printStackTrace();
	     }

	}
	
	// convert bytes to human readable account size 
	public static String humanReadableByteCountBin(long bytes) {
	    long absB = bytes == Long.MIN_VALUE ? Long.MAX_VALUE : Math.abs(bytes);
	    if (absB < 1024) {
	        return bytes + " B";
	    }
	    long value = absB;
	    CharacterIterator ci = new StringCharacterIterator("KMGTPE");
	    for (int i = 40; i >= 0 && absB > 0xfffccccccccccccL >> i; i -= 10) {
	        value >>= 10;
	        ci.next();
	    }
	    value *= Long.signum(bytes);
	    return String.format("%.1f %cB", value / 1024.0, ci.current());
	}
}
import io.swagger.client.*;
import io.swagger.client.model.*;
import io.swagger.client.auth.*;
import io.swagger.client.api.AccountApi;

import com.google.gson.internal.LinkedTreeMap;

import java.text.CharacterIterator;
import java.text.StringCharacterIterator;

import java.util.*;


public class GetAccount extends JavaExamples {
	
	/**
	 * GetAccount - Use the AccountApi to return your account info, check disk usage and use include param to return master user
	 */

	/**
	 * To use this example, add your credentials to main JavaExamples class in this project
	 * 
	 * 
	 * To obtain your API Key and Token, you'll need to use the Developer page within the web file manager
	 * See https://www.exavault.com/developer/api-docs/#section/Obtaining-Your-API-Key-and-Access-Token
	 * 
	 * Access tokens do not expire, so you should only need to obtain the key and token once.
	 * 
	 */
	
	/**
	 * 
	 *  We are demonstrating the use of the AccountAPI, which can be used to manage the account settings 
	 *
	 */

	public static void main(String[] args) {
		
		// Construct main class to set evAccessToken, evApiKey and apiUrl
		JavaExamples ob1 = new JavaExamples();
		
		
	    AccountApi accountApiInstance = new AccountApi(apiInstance);
	    
	    // Include masterUser in response
	    String include = "masterUser";
	    

	     try {
	    	 // The getAccount method of the AccountApi class will give us access to the current status of our account
	    	 // See https://www.exavault.com/developer/api-docs/#operation/getAccount for the details of this method
	    	 AccountResponse result = accountApiInstance.getAccount(evApiKey, evAccessToken, include);
	    	 
	    	 // The AccountResponse object that we got back (result) is composed of additional, nested objects
	    	 // See https://www.exavault.com/developer/api-docs/#operation/getAccount for the details of the response object
	         long percentUsed = Math.round((double)result.getData().getAttributes().getQuota().getDiskUsed() / (double)result.getData().getAttributes().getQuota().getDiskLimit() * 100);
	         
	         // The values returned in the Quota object are given in bytes, so we convert that to GB and print out
	         System.out.println("Used: " + humanReadableByteCountBin(result.getData().getAttributes().getQuota().getDiskUsed()) + " (" + percentUsed + "%)"  );
	         System.out.println("Total size: " + humanReadableByteCountBin(result.getData().getAttributes().getQuota().getDiskLimit()));
	         
	         // Included is an array of generic objects
	         // You need to cast it to LinkedTreeMap class to get data from it
	         List<Object> included = result.getIncluded();
	         LinkedTreeMap user = (LinkedTreeMap) included.get(0);
	         
	         // Print out master user id
	         System.out.println("Master user id: " + ((Double) user.get("id")).intValue());
	     } catch (ApiException e) {
	         System.err.println("Exception when calling AccountApi#getAccount");
	         e.printStackTrace();
	     }

	}
	
	// helper funtion to  convert bytes to human readable account size 
	public static String humanReadableByteCountBin(long bytes) {
	    long absB = bytes == Long.MIN_VALUE ? Long.MAX_VALUE : Math.abs(bytes);
	    if (absB < 1024) {
	        return bytes + " B";
	    }
	    long value = absB;
	    CharacterIterator ci = new StringCharacterIterator("KMGTPE");
	    for (int i = 40; i >= 0 && absB > 0xfffccccccccccccL >> i; i -= 10) {
	        value >>= 10;
	        ci.next();
	    }
	    value *= Long.signum(bytes);
	    return String.format("%.1f %cB", value / 1024.0, ci.current());
	}
}
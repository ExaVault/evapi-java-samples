import io.swagger.client.*;
import io.swagger.client.auth.*;
import io.swagger.client.model.*;
import io.swagger.client.api.ActivityApi;
import org.threeten.bp.OffsetDateTime;

public class GetActivity extends JavaExamples {
	
	public static void main(String[] args) {
		
		 JavaExamples ob1 = new JavaExamples();
		 
		 ActivityApi activityApiInstance = new ActivityApi(apiInstance);

	     Integer offset = 0; // Integer | Offset of the records list
	     Integer limit = 200; // Integer | Limit of the records list
	     String userName = null; // String | Username used for filtering a list
	     String path = null; // String | Path used to filter records
	     String ipAddress = null; // String | Used to filter session logs by ip address
	     String type = "PASS"; // String | Filter session logs for operation type
	     OffsetDateTime startDate = OffsetDateTime.now().minusDays(1); // OffsetDateTime | Start date of the filter data range
	     OffsetDateTime endDate = OffsetDateTime.now(); // OffsetDateTime | End date of the filter data range
	     String sort = null; // String | Comma separated list sort params

	     //Get failed logins
	     try {
	         SessionActivityResponse result = activityApiInstance.getSessionLogs(evApiKey, evAccessToken, startDate, endDate, ipAddress, userName, path, type, offset, limit, sort);
	         System.out.println(result);
	     } catch (ApiException e) {
	         System.err.println("Exception when calling ActivityApi#getSessionLogs");
	         e.printStackTrace();
	     }


	}
}
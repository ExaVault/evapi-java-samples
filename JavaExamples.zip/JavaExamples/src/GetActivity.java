import io.swagger.client.*;
import io.swagger.client.auth.*;
import io.swagger.client.model.*;
import io.swagger.client.api.ActivityApi;
import org.threeten.bp.OffsetDateTime;

public class GetActivity extends JavaExamples {
	
	/**
	 * GetActivity - Use the ActivityApi to retrieve the login operation from your account
	 * 
	 */

	/**
	 * To use this example, add your credentials to main JavaExamples class in this project
	 * 
	 * 
	 * To obtain your API Key and Token, you'll need to use the Developer page within the web file manager
	 * See https://www.exavault.com/developer/api-docs/#section/Obtaining-Your-API-Key-and-Access-Token
	 * 
	 * Access tokens do not expire, so you should only need to obtain the key and token once.
	 * 
	 */
	
	 /**
	  * We are demonstrating the use of the ActivityApi, which can be used to retrieve session and webhook logs
	  * 
	  */
	
	public static void main(String[] args) {
		
		 // Construct main class to set evAccessToken, evApiKey and apiUrl
		 JavaExamples ob1 = new JavaExamples();
		 
		 // The getSessionLogs method of the ActivityApi class will give us access activity logs for our account
		 // See https://www.exavault.com/developer/api-docs/#operation/getSessionLogs for the details of this method
		 ActivityApi activityApiInstance = new ActivityApi(apiInstance);

	     Integer offset = 0; // Integer | Offset of the records list
	     Integer limit = 200; // Integer | Limit of the records list
	     String userName = null; // String | Username used for filtering a list
	     String path = null; // String | Path used to filter records
	     String ipAddress = null; // String | Used to filter session logs by ip address
	     String type = "PASS"; // String | Filter session logs for operation type
	     OffsetDateTime startDate = OffsetDateTime.now().minusDays(1); // OffsetDateTime | Start date of the filter data range
	     OffsetDateTime endDate = OffsetDateTime.now(); // OffsetDateTime | End date of the filter data range
	     String sort = null; // String | Comma separated list sort params

	     try {
	    	 //Returns all login activity for the accout for the past day
	    	 // See https://www.exavault.com/developer/api-docs/#operation/getSessionLogs for the details of the response object
	         SessionActivityResponse result = activityApiInstance.getSessionLogs(evApiKey, evAccessToken, startDate, endDate, ipAddress, userName, path, type, offset, limit, sort);
	         System.out.println(result);
	     } catch (ApiException e) {
	         System.err.println("Exception when calling ActivityApi#getSessionLogs");
	         e.printStackTrace();
	     }


	}
}
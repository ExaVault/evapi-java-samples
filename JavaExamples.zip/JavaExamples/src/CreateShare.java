import io.swagger.client.*;
import io.swagger.client.auth.*;
import io.swagger.client.model.*;
import io.swagger.client.api.SharesApi;
import io.swagger.client.api.ResourcesApi;
import java.util.*;


public class CreateShare extends JavaExamples {
	
	/**
	 * CreateShare - Use the SharesApi to create a shared folder with a password
	 * 
	 */

	/**
	 * To use this example, add your credentials to main JavaExamples class in this project
	 * 
	 * 
	 * To obtain your API Key and Token, you'll need to use the Developer page within the web file manager
	 * See https://www.exavault.com/developer/api-docs/#section/Obtaining-Your-API-Key-and-Access-Token
	 * 
	 * Access tokens do not expire, so you should only need to obtain the key and token once.
	 * 
	 */
	
	 /**
	  * 
	  * We are demonstrating the use of the SharesApi, which is used for managing shared folders and receives,
	  * as well as for sending files. See our Sharing 101 documentation at
	  * https://www.exavault.com/docs/account/05-file-sharing/00-file-sharing-101
	  *
	  * For this demo, we'll create a share for a new folder. If you have an existing file or folder that you want to use 
	  * for the share, you won't need this step where we use the ResourcesApi to create the folders first.
	  * 
	  */
	
	public static void main(String[] args) {
		
		// Construct main class to set evAccessToken, evApiKey and apiUrl
		JavaExamples ob1 = new JavaExamples();
		
		ResourcesApi resourcesApiInstance = new ResourcesApi(apiInstance);
		
		
		Random rand = new Random();
		
		// create folder to share it
		// See https://www.exavault.com/developer/api-docs/#operation/addFolder for the request body schema
		Body8 body = new Body8();
	    body.setPath("/java-upload/share-sample"+rand.nextInt());
	    Integer folderId = null;
	    
	    try {
	    	// See https://www.exavault.com/developer/api-docs/#operation/addFolder for the details of this method
	        ResourceResponse result = resourcesApiInstance.addFolder(evApiKey, evAccessToken, body);
	        
	        // Get id of the folder we've just created
	        folderId = result.getData().getId();
	    } catch (ApiException e) {
	        System.err.println("Exception when calling ResourcesApi#addFolder");
	        e.printStackTrace();
	    }
	     
	    SharesApi sharesApiInstance = new SharesApi(apiInstance);
	    
	    // See https://www.exavault.com/developer/api-docs/#operation/addShare for the request body schema
	    Body16 body16 = new Body16(); 
	     
	    
	    // - We want to add a password to our folder
	    // - We are also going to allow visitors to download only
	    // - We are using ID as identifier for the new folder we've created
	    // - We could also have used the full path to the folder
	    List<String> resources =  Arrays.asList("id:"+folderId);
	    List<String> accessMode =  Arrays.asList("download");
	    
	    body16.setType(Body16.TypeEnum.SHARED_FOLDER);
	    body16.setName("notification-sample");
	    body16.setResources(resources);
	    body16.setPassword("testpAssword8");
	    body16.setAccessMode(accessMode);
	     
	     
	    try {
	    	
	    	//  See https://www.exavault.com/developer/api-docs/#operation/addShare for the response schema
	        ShareResponse result = sharesApiInstance.addShare(evApiKey, evAccessToken, body16);
	        
	        //print out the response 
	        System.out.println(result);
	    } catch (ApiException e) {
	        System.err.println("Exception when calling SharesApi#addShare");
	        e.printStackTrace();
	    }
		
	}

}

import io.swagger.client.*;
import io.swagger.client.auth.*;
import io.swagger.client.model.*;
import io.swagger.client.api.SharesApi;
import io.swagger.client.api.ResourcesApi;
import java.util.*;


public class CreateShare extends JavaExamples {
	
	public static void main(String[] args) {
		
		JavaExamples ob1 = new JavaExamples();
		
		ResourcesApi resourcesApiInstance = new ResourcesApi(apiInstance);
		SharesApi sharesApiInstance = new SharesApi(apiInstance);
		
		Random rand = new Random();
		
		// create folder to set notification on it
		Body8 body = new Body8(); // Body8 | 
	    body.setPath("/java-upload/share-sample"+rand.nextInt());
	    Integer folderId = null;
	    
	    try {
	        ResourceResponse result = resourcesApiInstance.addFolder(evApiKey, evAccessToken, body);
	        
	        folderId = result.getData().getId();
	        System.out.println(result);
	    } catch (ApiException e) {
	        System.err.println("Exception when calling ResourcesApi#addFolder");
	        e.printStackTrace();
	    }
	    
	    Body16 body16 = new Body16(); // Body16 | 
	     
	    List<String> resources =  Arrays.asList("id:"+folderId);
	    List<String> accessMode =  Arrays.asList("download");
	    
	    
	    body16.setType(Body16.TypeEnum.SHARED_FOLDER);
	    body16.setName("notification-sample");
	    body16.setResources(resources);
	    body16.setPassword("testpAssword8");
	    body16.setAccessMode(accessMode);
	     
	     
	    try {
	        ShareResponse result = sharesApiInstance.addShare(evApiKey, evAccessToken, body16);
	        System.out.println(result);
	    } catch (ApiException e) {
	    	System.err.println(e.getResponseBody());
	        System.err.println("Exception when calling SharesApi#addShare");
	        e.printStackTrace();
	    }
		
	}

}

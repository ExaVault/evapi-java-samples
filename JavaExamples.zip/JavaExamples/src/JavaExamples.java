import io.swagger.client.*;
import io.swagger.client.auth.*;

public class JavaExamples {
	
	/** 
	 * Obtain your API key and Access Token from the Developer tab of the ExaVault File Manager
	 * See https://www.exavault.com/developer/api-docs/v2#section/Obtaining-Your-API-Key-and-Access-Token
	 * Your account URL is determined by the name of your account. 
	 * 
	 * The URL that you will use is https://accountname.exavault.com/api/v2/ replacing the "accountname" part with your
	 *   account name
	 *   
	 * See https://www.exavault.com/developer/api-docs/#section/Introduction/The-API-URL
	 */
	
	 public static String evApiKey = "[evApiKey]"; 
     public static String evAccessToken = "[evAccessToken]"; 
     public static String apiUrl = "https://[accountName].exavault.com/api/v2";
	
     public static ApiClient apiInstance; 
     
    public JavaExamples () {
    	ApiClient apiClient = new ApiClient();
        apiClient.setBasePath(apiUrl);
        apiInstance = apiClient;	
    }
    
}

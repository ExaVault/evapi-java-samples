import io.swagger.client.*;
import io.swagger.client.auth.*;

public class JavaExamples {
	
	 public static String evApiKey = "[evApiKey]"; // String | Optional if seeking limited info about account, and ev-access-token is provided.
     public static String evAccessToken = "[evAccessToken]"; // String | Optional if seeking limited info about account, and ev-api-key is present
     public static String apiUrl = "https://[accountName].exavault.com/api/v2";
	
     public static ApiClient apiInstance; 
     
    public JavaExamples () {
    	ApiClient apiClient = new ApiClient();
        apiClient.setBasePath(apiUrl);
        apiInstance = apiClient;	
    }
    
}
